#pragma once
#include "common.h"
#include <chrono>

ABEOSYS_NS_START

class TicToc{
  public:
    TicToc();

    void tic();
    //! Get current elapsed time since tic()
    double elapsed()const;
    //! Get current elapsed time since tic() and reset timer
    double toc();

  protected:
    std::chrono::steady_clock::time_point t0;
};

ABEOSYS_NS_END



