#pragma once

//Make RGB565
#define _RGB565(r,g,b) (((r>>3)<<11)|((g>>2)<<5)|(b>>3))
#define _RGB(r,g,b)    ((r<<16)|(g<<8)|b)
#define _RGBA(r,g,b,a) ((a<<24)|(r<<16)|(g<<8)|b)

