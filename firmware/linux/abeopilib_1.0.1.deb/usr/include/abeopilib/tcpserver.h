#pragma once
#include <string>
#include "common.h"
#include "exception.h"
#include "textcmd.h"

ABEOSYS_NS_START

DEF_EXCEPTION_(ConnectionLostException, "Connection lost!");



//TCP channel reperenting a socket connection between server and client
//server can use this channel to communicate with client using basic interface
class TCPChannel
{
public:
  TCPChannel(int client_socket);
  ~TCPChannel();
  //close channel
  void close() const;

  //Receive message from client, this call blocks
  //Return bytes read.
  //  Return 0 on connection lost
  //  return -1 on error
  size_t receive();
  std::string readLn();

  size_t read(char *buf, size_t len);

  //send strign message to client
  size_t send(std::string const &msg);

  //send data to client
  size_t send(char const *buf, int len);

  void runCommandLoop(CommandMap const &cmdmap);
  //get buffer max size
  const int getBufferMaxSize() const;
  //Get client socket number
  const int getSocket() const;
  //Get buffer contents
  char const *getBuffer() const;

private:
  int m_socket;             //client socket
  char *m_buffer = nullptr; //data buffer
};

using TcpClientCallback = std::function<void(TCPChannel)>;
using TcpClientServiceCallback = std::function<void(TCPChannel &)>;
using TcpClientPreServiceCallback = std::function<void()>;
using TcpClientPostServiceCallback = std::function<void()>;

//TCP server class
class TCPServer
{
public:
  TCPServer()=default;
  ~TCPServer();

  void run(int portno,
           TcpClientPreServiceCallback fn_PreService,
           TcpClientPostServiceCallback fn_PostService,
           TcpClientServiceCallback fn_Service);

  //Wait for new connection
  void waitForClient(int port, TcpClientCallback client_callback);
  //Return server socket
  int getSocket() const;

private:
  int m_serverSocket = -1;
};

ABEOSYS_NS_END
