#pragma once
#include "common.h"

#define HIGH 1
#define LOW 0

ABEOSYS_NS_START



enum class BoardName{
    PI3,
    PI4,
    PIZero,
};



class GPIO{
public:

    //Pin mode
    enum Mode{
        Input = 0,
        Output,
    };

    //Default ctor
    GPIO(BoardName board_name);

    //Dtor: Unmap GPIO memory
    ~GPIO();

    //Set pin mode
    void pinMode(int pin, Mode mode);

    //Set a pin (true: high, false: low)
    inline void setPin(int pin, bool value){
        if(value)*m_gpio_set = 1 << pin;
        else *m_gpio_clr = 1 << pin;
    }

    //Set a pin to high
    inline void setPin(int pin){ *m_gpio_set = (1 << pin); }

    //Set a pin to low
    inline void clrPin(int pin){ *m_gpio_clr = (1 << pin); }

    //Get logic level of a pin
    inline bool getPin(int pin){ return (*m_gpio_reg)&(1<< pin); }

    //Get GPIO register
    //This is useful if we need to read many pins
    inline uint32_t getGPIOReg(){ return *m_gpio_reg; }

private:
    volatile unsigned* m_gpio = nullptr;
    volatile unsigned* m_gpio_set = nullptr;
    volatile unsigned* m_gpio_clr = nullptr;
    volatile unsigned* m_gpio_reg = nullptr;
    int m_fd = -1;
};

ABEOSYS_NS_END
