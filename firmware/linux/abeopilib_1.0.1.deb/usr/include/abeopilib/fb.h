#pragma once
#include <linux/fb.h>
#include "common.h"
#include "color.h"
#include "type.h"
#include "font.h"

//set 16bit fb command
//fbset -fb /dev/fb0 -depth 16


#define FB_COLOR_DEPTH 16 
#define FB_BITS_PER_PIXEL  FB_COLOR_DEPTH
#define FB_BYTES_PER_PIXEL (FB_BITS_PER_PIXEL/8)

ABEOSYS_NS_START

class FrameBuffer{
public:
    /**
     * Construct gramebuffer object
     */
    FrameBuffer(char const* fbdev = "/dev/fb0");
    ~FrameBuffer();

    //Clear framebuffer with current selected color
    void clear();

    //Set pixel(x,y) with current color
    void setPixel(int x, int y);

    //Get color at pixel(x,y) on frame buffer
    uint32_t getPixel(int x, int y);

    //Draw vertical line
    void vline(int x, int y0, int y1);

    //Draw horizontal line
    void hline(int x0, int x1, int y);

    //Draw a rectangle
    void rect(int x, int y, int w, int h);

    //Draw a line
    void line(int x0, int y0, int x1, int y1);

    //Draw a circle
    void circle(int xc, int yc, int rad);

    //Draw an ellipse
    void ellipse(int x, int y, int w, int h);

    //Fill framebuffer with vertical stripes pattern
    //given by first row data
    void fillVPattern(ushort* line_data);

    //Fill framebuffer with horizontal stripes pattern
    //given by first column data
    void fillHPattern(ushort* col_data);

    //Flip back buffer to front
    void flip();

    //Draw bezier curve
    void bezier(int x0, int y0, int x1, int y1, int x2, int y2);

    //Put a character on screen at (x,y)
    void putc(char c, int x, int y);

    //Put a string on screen starting at (x,y)
    void puts(char const* str, int x, int y);

    //Set font
    inline void setFont(uint8_t* font){ m_font = font; }
    //Set current color
    inline void setColor(uint color){ m_color = color; }
    //Set current color
    inline void setColor(uint8_t r, uint8_t g, uint8_t b){ m_color = _RGB565(r, g, b); }

    //Return the width of the frame buffer
    inline int width()const{ return m_fb_vinfo.xres; }
    //Return the height of the frame buffer
    inline int height()const{ return m_fb_vinfo.yres; }
    //Return the framebuffer's bits per pixel
    inline int bpp()const{ return m_fb_vinfo.bits_per_pixel; }
    //Return framebuffer row memory size in bytes
    inline int lineLength()const{ return m_fb_finfo.line_length; }
    //Return the framebuffer memory size in bytes
    inline int memLength()const{ return m_memLength; }
    //Get data pointer
    inline void* data()const{return m_scrbuf;}
    inline void* data(){return m_scrbuf;}

private:

    inline void _setPixel(int x, int y){
    #if FB_BYTES_PER_PIXEL == 2
        ((uint16_t*)m_scrbuf)[y*width() + x] = m_color;
    #elif FB_BYTES_PER_PIXEL == 3
        auto *ptr = m_scrbuf + lineLength()*y + x * 3;
        ptr[0] = m_color & 0xFF;
        ptr[1] = (m_color >> 8) & 0xFF;
        ptr[2] = (m_color >> 16) & 0xFF;
    #elif FB_BYTES_PER_PIXEL == 4
        ((uint32*)m_scrbuf)[y*width() + x] = m_color;
    #endif
    }
    inline void _setPixel(int offset){
    #if FB_BYTES_PER_PIXEL == 2
        ((uint16_t*)m_scrbuf)[offset] = m_color;
    #elif FB_BYTES_PER_PIXEL == 3
        auto *ptr = offset * 3;
        ptr[0] = m_color & 0xFF;
        ptr[1] = (m_color >> 8) & 0xFF;
        ptr[2] = (m_color >> 16) & 0xFF;
    #elif FB_BYTES_PER_PIXEL == 4
        ((uint32*)m_scrbuf)[offset] = m_color;
    #endif
    }

    inline uint32 _getPixel(int x, int y){
    #if FB_BYTES_PER_PIXEL == 2
        return ((uint16_t*)m_scrbuf)[y*width() + x];
    #elif FB_BYTES_PER_PIXEL == 3
        auto *ptr = m_scrbuf + lineLength()*y + x * 3;
        return _RGB(ptr[0], ptr[1], ptr[2]);
    #elif FB_BYTES_PER_PIXEL == 4
        return ((uint32*)m_scrbuf)[y*width() + x];
    #endif
    }

    struct fb_var_screeninfo m_fb_vinfo;
    struct fb_fix_screeninfo m_fb_finfo;
    int m_fbfd = -1;
    uint32_t m_memLength = 0;
    uint m_color = 0;
    uint8_t* m_font = Font6x12;
    uint8_t* m_fbptr = nullptr;  //framebuffer memory pointer
    uint8_t* m_scrbuf = nullptr; //screen buffer memory pointer
};

ABEOSYS_NS_END


