#pragma once
#include <thread>
#include <vector>
#include "common.h"

#ifndef MAX_THREAD
#   define MAX_THREAD 4
#endif


ABEOSYS_NS_START

//Run a function in parallel
//Function must have following signature:
// void func(int thread_id)
template<class Func>
void run_parallel(Func&& func){
    std::vector<std::thread> ths;
    for(int i = 0; i < MAX_THREAD; i++) ths.push_back(std::thread(func, i));
    for(auto& th : ths)th.join();
}

ABEOSYS_NS_END
