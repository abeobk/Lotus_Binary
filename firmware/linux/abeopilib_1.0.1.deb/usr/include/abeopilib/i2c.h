#pragma once
#include "common.h"

ABEOSYS_NS_START
class I2CDevice{
public:
    //Initialize I2C device
    I2CDevice(char const* dev);
    ~I2CDevice(); 

    //Queries if the i2c device is properly opened
    bool isOpened()const;

    //Set slave address for later access operations
    bool setSlaveAddr(uint8_t addr);

    //Write to i2c device
    int write(uint8_t const* buf, int len);

    //Read from i2c device
    int read(uint8_t *buf, int len);

private:
    int m_i2cfd = -1;
};

ABEOSYS_NS_END
