#pragma once

#define ABEOSYS_NS_START namespace abeosys{
#define ABEOSYS_NS_END   }
