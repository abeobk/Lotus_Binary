#pragma once

#include "common.h"
#include <stdexcept>
#include <string>

#define DEF_EXCEPTION_(classname,default_msg) class classname\
:public std::runtime_error{ \
public: \
explicit classname(std::string const& msg=default_msg): std::runtime_error(msg){}\
}
