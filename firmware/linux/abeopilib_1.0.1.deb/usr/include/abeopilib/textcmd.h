#pragma once

#include "common.h"
#include <string>
#include <sstream>
#include <vector>
#include <functional>
#include <map>

ABEOSYS_NS_START

struct TextCommand{
    std::string cmd;
    std::vector<std::string> args;
    int idx=0;

    TextCommand(std::string msg);
    int argCount()const;
    void assertArgCount(int cnt)const;
    void assertIndex(int i)const;
    int getInt(int i)const;
    long int getLong(int i)const;
    double getDouble(int i)const;
    float getFloat(int i)const;
    std::string getString(int i)const;
    std::string getRemainString(int i);
    inline void init(){idx=0;}
    inline int nextInt(){return getInt(idx++);}
    inline long int nextLong(){return getLong(idx++);}
    inline double nextDouble(){return getDouble(idx++);}
    inline float nextFloat(){return getFloat(idx++);}
    inline std::string nextString(){return getString(idx++);}
    inline std::string remainString(){return getRemainString(idx++);}
};

struct CommandExecutor{
    std::function<void(TextCommand const& cmd)> fn;
    std::string desc;
    inline CommandExecutor(std::function<void(TextCommand const&)> fn_, std::string desc_):fn(fn_), desc(desc_){}
};

using CommandMap = std::map<std::string,CommandExecutor>;

ABEOSYS_NS_END


